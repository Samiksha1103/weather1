import csv
import math
import random

Weather123 = open('weatherdata.csv','r')
FormattedData = list(csv.reader(Weather123))

NecessaryData = []

for EachData in FormattedData[1:]:
    BlankList = []
    BlankList.append(float(EachData[3]))
    BlankList.append(EachData[7])
    NecessaryData.append(BlankList)

TrainingData = NecessaryData[17:157]
TestingData = []

for EachData in NecessaryData[0:17]:
    TestingData.append(EachData)

for EachData in NecessaryData[157:175]:
    TestingData.append(EachData)

#Theta0 = random.randint(0,255)
#Theta1 = random.randint(0,255)
Theta0 = 1
Theta1 = 1
alpha = 0.0001


for iterations in range(0,40000):
    Del_Theta0_Smoke = 0
    Del_Theta1_Smoke = 0
    Del_Theta0_Clear = 0
    Del_Theta1_Clear = 0
    Del_Theta0 = 0
    Del_Theta1 = 0
    LF = 0

    for EachData in TrainingData[0:80]:
        Del_Theta0_Smoke = Del_Theta0_Smoke + (1/(1+math.exp(Theta0 + (Theta1*EachData[0]))))
        Del_Theta1_Smoke = Del_Theta1_Smoke + (EachData[0]/(1+math.exp(Theta0 + (Theta1*EachData[0]))))

    for EachData in TrainingData[80:140]:
        b=0
        b=math.exp(-(Theta0+(Theta1*EachData[0])))
        Del_Theta0_Clear = Del_Theta0_Clear - (1/(1+b))
        Del_Theta1_Clear = Del_Theta1_Clear - (EachData[0]/(1+b))

    Del_Theta0 = Del_Theta0_Smoke + Del_Theta0_Clear
    Del_Theta1 = Del_Theta1_Smoke + Del_Theta1_Clear

    Theta0 = Theta0 + (alpha * Del_Theta0)
    Theta1 = Theta1 + (alpha * Del_Theta1)

    for EachData in TrainingData[0:80]:
        c=math.exp(-(Theta0+(Theta1*EachData[0])))
        LF = LF + math.log(1/(1+c))

    for EachData in TrainingData[80:140]:
        d=math.exp(-(Theta0+(Theta1*EachData[0])))
        LF = LF + math.log(1 - (1/(1+d)))

    print("The value of Likelihood function at iteration number {} is {}".format(iterations,LF))

    iterations += 1

#testing
CorrectCount1 = 0
CorrectCount2= 0
for EachData in TestingData[0:35]:
    e=math.exp(-(Theta0+(Theta1*EachData[0])))
    PriorProb= (1/(1+e))
    if PriorProb > 0.5 and EachData[1] == 'Smoke':
        CorrectCount1 += 1
        print('Smoke')
    elif PriorProb < 0.5 and EachData[1] == 'Clear':
        CorrectCount2 += 1
        print('Clear')
#print('Value of count ='+str(CorrectCount)
accuracy=((CorrectCount1+CorrectCount2)/35)*100
print(accuracy)
#print('Value of count2 ='+str(CorrectCount2))



